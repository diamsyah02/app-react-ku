self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c537a15057f82aab5e06e4cf0ec9c112",
    "url": "/index.html"
  },
  {
    "revision": "0342bb7d6f0b5bf88651",
    "url": "/static/css/2.47e06e2e.chunk.css"
  },
  {
    "revision": "b60fc3f7304d8980fe91",
    "url": "/static/css/main.acef0dcb.chunk.css"
  },
  {
    "revision": "0342bb7d6f0b5bf88651",
    "url": "/static/js/2.6b12f884.chunk.js"
  },
  {
    "revision": "bf23039b4e70a07c5aeb1b4010df3572",
    "url": "/static/js/2.6b12f884.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b60fc3f7304d8980fe91",
    "url": "/static/js/main.94bc9df6.chunk.js"
  },
  {
    "revision": "fa381fa9a0e76b4af4c0",
    "url": "/static/js/runtime-main.e24048cd.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);